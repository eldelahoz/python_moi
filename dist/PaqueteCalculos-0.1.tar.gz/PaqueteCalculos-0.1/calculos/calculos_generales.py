def sumar(op1, op2):
    print("El resultado es:", op1+op2)


def restar(op1, op2):
    print("El resultado es:", op1-op2)


def multiplicar(op1, op2):
    print("El resultado es:", op1*op2)


def dividir(dividendo, divisor):
    print("El resultado es:", dividendo/divisor)


def potencia(base, exponente):
    print("El resultado es:", base**exponente)


def redondear(numero):
    print("El resultado es:", round(numero))


