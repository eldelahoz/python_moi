from setuptools import setup

setup(
    name="PaqueteCalculos",
    version="0.1",
    description="Paquete de redondeo y potencia",
    author="Andres De la Hoz",
    author_email="andelahoz13@gmail.com",
    url="localhost",
    packages=["calculos", "calculos.redondeo_potencia"]
)